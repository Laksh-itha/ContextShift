// ContextShift – Copilot content script
// Re-reads the chat whenever it changes (new messages, streaming replies,
// switching chats) and sends it to the extension. It never stops watching.

const SOURCE_AI = "Copilot";

let lastSignature = "";
let timer = null;

function extract() {
  const conversation = [];

  const chatPage = document.querySelector("[data-testid=\"chat-page\"]");
  if (!chatPage) return conversation;

  const turns = chatPage.querySelectorAll(
    "[data-content=\"user-message\"], [data-testid=\"ai-message\"]"
  );

  turns.forEach((turn) => {
    if (turn.matches("[data-content=\"user-message\"]")) {
      const content = turn.innerText ? turn.innerText.trim() : "";
      if (content) conversation.push({ role: "user", content: content });
      return;
    }

    const body = turn.querySelector("[data-testid=\"ai-message-body\"]");
    const content = body && body.innerText ? body.innerText.trim() : "";
    if (content) conversation.push({ role: "assistant", content: content });
  });

  return conversation;
}

function sendIfChanged() {
  const conversation = extract();

  if (conversation.length === 0) return;

  const signature = JSON.stringify(conversation);
  if (signature === lastSignature) return;
  lastSignature = signature;

  try {
    const result = chrome.runtime.sendMessage({
      type: "CONVERSATION",
      sourceAI: SOURCE_AI,
      conversation: conversation
    });
    if (result && result.catch) result.catch(() => {});
  } catch (error) {
    // The extension was reloaded while this tab was open. Refresh the page.
  }
}

const observer = new MutationObserver(() => {
  clearTimeout(timer);
  timer = setTimeout(sendIfChanged, 1000);
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

sendIfChanged();
