chrome.runtime.onMessage.addListener((message) => {
  if (message.type !== "CONVERSATION") return;

  if (!message.conversation || message.conversation.length === 0) {
    return;
  }

  chrome.storage.local.set({
    conversation: message.conversation,
    sourceAI: message.sourceAI || ""
  });
});
