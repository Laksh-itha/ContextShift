// ContextShift – Claude content script
// Re-reads the chat whenever it changes (new messages, streaming replies,
// switching chats) and sends it to the extension. It never stops watching.

const SOURCE_AI = "Claude";

let lastSignature = "";
let timer = null;

function extract() {
  const conversation = [];

  document.querySelectorAll("[data-testid=\"transcript-row\"]").forEach((row) => {
    const content = row.innerText ? row.innerText.trim() : "";

    if (!content) return;

    const isUser = row.querySelector("[data-testid=\"user-message\"]");

    conversation.push({
      role: isUser ? "user" : "assistant",
      content: content
    });
  });

  return conversation;
}

function sendIfChanged() {
  const conversation = extract();

  if (conversation.length === 0) return;

  const signature = JSON.stringify(conversation);
  if (signature === lastSignature) return;
  lastSignature = signature;

  try {
    const result = chrome.runtime.sendMessage({
      type: "CONVERSATION",
      sourceAI: SOURCE_AI,
      conversation: conversation
    });
    if (result && result.catch) result.catch(() => {});
  } catch (error) {
    // The extension was reloaded while this tab was open. Refresh the page.
  }
}

const observer = new MutationObserver(() => {
  clearTimeout(timer);
  timer = setTimeout(sendIfChanged, 1000);
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

sendIfChanged();
