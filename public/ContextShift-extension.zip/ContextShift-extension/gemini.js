// ContextShift – Gemini content script
// Re-reads the chat whenever it changes (new messages, streaming replies,
// switching chats) and sends it to the extension. It never stops watching.

const SOURCE_AI = "Gemini";

let lastSignature = "";
let timer = null;

function extract() {
  const conversation = [];

  document.querySelectorAll("user-query, model-response").forEach((turn) => {
    const content = turn.innerText ? turn.innerText.trim() : "";

    // Skip elements that have not finished rendering
    if (!content) return;

    if (turn.matches("user-query")) {
      conversation.push({ role: "user", content: content });
    } else if (turn.matches("model-response")) {
      conversation.push({ role: "assistant", content: content });
    }
  });

  return conversation;
}

function sendIfChanged() {
  const conversation = extract();

  if (conversation.length === 0) return;

  const signature = JSON.stringify(conversation);
  if (signature === lastSignature) return;
  lastSignature = signature;

  try {
    const result = chrome.runtime.sendMessage({
      type: "CONVERSATION",
      sourceAI: SOURCE_AI,
      conversation: conversation
    });
    if (result && result.catch) result.catch(() => {});
  } catch (error) {
    // The extension was reloaded while this tab was open. Refresh the page.
  }
}

const observer = new MutationObserver(() => {
  clearTimeout(timer);
  timer = setTimeout(sendIfChanged, 1000);
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

sendIfChanged();
